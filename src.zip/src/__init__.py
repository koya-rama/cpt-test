"""Nemotron Continuous Pre-Training Pipeline"""
__version__ = "1.0.0"
